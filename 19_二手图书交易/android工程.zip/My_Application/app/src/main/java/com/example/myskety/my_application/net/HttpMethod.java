package com.example.myskety.my_application.net;

public enum HttpMethod {
	GET,POST
}
