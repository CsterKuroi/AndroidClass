import java.io.File;
import java.io.IOException;
import java.io.FileReader;
import java.io.LineNumberReader;
class IPSeeker{
    //Overview:���ļ�����ȡIP��ַ����
    private LineNumberReader seeker;
    IPSeeker(String FileName)throws IOException{
       seeker=new LineNumberReader(new FileReader(new File(FileName))); 
    }
    public String getIP()throws NullPointerException{
       //Effects:return the first line read by seeker begin with "IPv4"
       //throws NullPointerException if the process fails
       String line=null;
       int CharGet=0;//How many char of "IPv4" have get
       int l=0;//length of line
       boolean isHit=false;//hit segment
       while(true){
          try{
	     line=seeker.readLine();
          }
          catch(IOException ioe){
             ioe.printStackTrace();
          }
          if(line.equals("���߾����������� WLAN:")){
	     isHit=true;
             continue;
          }
          else if(!isHit)
             continue;
          l=line.length();
          char c=0;
          boolean skip=false;
          CharGet=0;
          for(int n=0;n<l;n++){
             c=line.charAt(n);
             switch(CharGet){
		case 0:
		   if(c=='I')
                      CharGet=1;
                   else if(c!=' ')
                      skip=true;
                   break;
		case 1:
                   if(c=='P')
                      CharGet=2;
                   else
                      skip=true;
		   break;
		case 2:
		   if(c=='v')
		      CharGet=3;
		   else
		      skip=true;
		   break;
		case 3:
		   if(c=='4')
		      CharGet=4;
		   skip=true;
 	     }
             if(skip)
                break;
          }
          if(CharGet==4)
            break;
       }
       return new String(line);  
    }
}