//Overview:�����࣬�����ļ���
import java.awt.event.InputEvent;

class Decoder{
    public int decode(String s)throws NullPointerException{
        int result;
        switch(s.charAt(0)){
            case 'D':
               
               break;
            case 'L':
               result=(s.equals("Left"))?InputEvent.BUTTON1_MASK:0;
               break;
            case 'R':
               result=(s.equals("Left"))?InputEvent.BUTTON1_MASK:0;
               break;
            default:
               result=0;
        }        
    }
}