package com.example.ljbo.touchpad_3;

/**记录触摸位置的数据结构
 * Created by LJbo on 2015/12/5.
 */
public class Position {
    public float x;
    public float y;
    Position(float f1,float f2) {
        x=f1;
        y=f2;
    }
}
