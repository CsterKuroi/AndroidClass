import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.AWTException;
class MouseController{
   private Robot robot;
   private int x;
   private int y;
   MouseController(){
      try{
         robot=new Robot();
      }
      catch(AWTException awte){
         awte.printStackTrace();
      }
      x=100;
      y=100;
      robot.mouseMove(x,y);
   }
   public void Control(String s)throws NullPointerException{
      switch(s.charAt(0)){
         case 'D':
            String str[]=s.split("\\(|\\,|\\)");
            if(str.length==3){
               x+=(int)Double.parseDouble(str[1]);
               y+=(int)Double.parseDouble(str[2]);
               robot.mouseMove(x,y);
            }
            System.out.println(str[0]+" "+str[1]+" "+str[2]+" "+x+" "+y);
            break;
         case 'C':
         case 'L':
            if(s.equals("Left")||s.equals("Click")){
               robot.mousePress(InputEvent.BUTTON1_MASK);
               robot.mouseRelease(InputEvent.BUTTON1_MASK);
            }
            break;
         case 'R':
            if(s.equals("Right")){
               robot.mousePress(InputEvent.BUTTON3_MASK);
               robot.mouseRelease(InputEvent.BUTTON3_MASK);
            }
            break;
          //default:do nothing
        }         
   }
}