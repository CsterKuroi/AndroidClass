package com.example.ljbo.touchpad_1;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.EditText;
import android.widget.ImageView;
import android.text.Editable;
import android.widget.Toast;//this may help
import android.graphics.*;

public class MainActivity extends ActionBarActivity {

    private EditText MsgText;
    private Editable msg;
    private ImageView image;
    private Bitmap bitmap;
    private Paint paint;
    private Canvas canvas;
    private float FormerX;
    private float FormerY;
    private int AmendH;//偏移量

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //below are my code
        View field=findViewById(R.id.IPField);
        MsgText=(EditText)findViewById(R.id.MsgEdit);
        image=(ImageView)findViewById(R.id.ImageView);
        //msg=MsgText.getEditableText();
        int w=2*getWindowManager().getDefaultDisplay().getWidth();
        int h=getWindowManager().getDefaultDisplay().getHeight();
        bitmap = Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);// 画板
        canvas.drawColor(Color.BLUE);
        paint = new Paint();// 画刷
        paint.setColor(Color.BLACK);//颜色
        paint.setStrokeWidth(20);//粗细
        image.setImageBitmap(bitmap);
        int width = View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED);
        int height = View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED);
        field.measure(width, height);
        AmendH =field.getMeasuredHeight()*3/2;
        MsgText.setText("onCreate:"+w+"*"+h+"&"+AmendH);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        x=x*2;
        switch(event.getAction()){
             case MotionEvent.ACTION_DOWN:
                 //MsgText.setText("down" + "(" + x + "," + y +")");
                 break;
             case MotionEvent.ACTION_UP:
                 //MsgText.setText("up" + "(" + x + "," + y +")");
                 //break;
             case MotionEvent.ACTION_MOVE:
                 //MsgText.setText("move" + "(" + x + "," + y +")");
                 canvas.drawLine(FormerX,FormerY,x,y,paint);//画线
                 image.invalidate();
                 break;
        }
        MsgText.setText("Touch:(" + x + "," + y + ")");
        //存储新值
        FormerX=x;
        FormerY=y;
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
