package com.example.ljbo.touchpad_2;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.graphics.*;


public class MainActivity extends ActionBarActivity {
    private remote client;
    private Button ConnectBtn;
    private Button LeftBtn;
    private Button RightBtn;
    private EditText IPText;
    private EditText msg;
    private ImageView image;
    private Bitmap bitmap;
    private Paint paint;
    private Canvas canvas;
    private float FormerX;
    private float FormerY;
    private TouchState state;
   // private int AmendH;//偏移量
    private OnClickListener ConnectButtonListener = new OnClickListener() {
        public void onClick(View v) {
            //below are my code
            try{
                client.IPchange((IPText.getText()).toString());
            }
            catch(NullPointerException npe){
                msg.setText("my"+(npe.getCause()).toString()+"\n");
                return;
            }
            catch(Exception e){
                msg.setText(e.getCause() + "\n");
                return;
            }
        }
    };
    private OnClickListener LeftButtonListener = new OnClickListener() {
        public void onClick(View v) {
            //below are my code
            try{
                client.Send("Left");
                state=TouchState.CLICK_LEFT;
                msg.setText("Left");
            }
            catch(NullPointerException npe){
                msg.setText("my"+(npe.getCause()).toString()+"\n");
                return;
            }
            catch(Exception e){
                msg.setText(e.getCause() + "\n");
                return;
            }
        }
    };
    private OnClickListener RightButtonListener = new OnClickListener() {
        public void onClick(View v) {
            //below are my code
            try{
                client.Send("Right");
                state=TouchState.CLICK_RIGHT;
                msg.setText("Right");
            }
            catch(NullPointerException npe){
                msg.setText("my"+(npe.toString()).toString());
                return;
            }
            catch(Exception e){
                msg.setText(e.toString());
                return;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //below are my code
        //初始化View
        client=new remote();
        ConnectBtn = (Button) findViewById(R.id.ConnectButton);
        LeftBtn = (Button) findViewById(R.id.LeftButton);
        RightBtn=(Button)findViewById(R.id.RightButton);
        msg=(EditText)findViewById(R.id.MsgEdit);
        IPText=(EditText)findViewById(R.id.IPEdit);
        image=(ImageView)findViewById(R.id.ImageView);
        //设置按键监听
        ConnectBtn.setOnClickListener(ConnectButtonListener);
        LeftBtn.setOnClickListener(LeftButtonListener);
        RightBtn.setOnClickListener(RightButtonListener);
        //设置画图工具
        int w=2*getWindowManager().getDefaultDisplay().getWidth();
        int h=getWindowManager().getDefaultDisplay().getHeight();
        bitmap = Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);// 画板
        canvas.drawColor(Color.BLUE);
        paint = new Paint();// 画刷
        paint.setColor(Color.BLACK);//颜色
        paint.setStrokeWidth(20);//粗细
        image.setImageBitmap(bitmap);
        //获取漂移
        /*
        int width = View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED);
        int height = View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED);
        field.measure(width, height);
        AmendH =field.getMeasuredHeight()*3/2;
        */
        //完成
        msg.setText("onCreate:" + w + "*" + h );
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        switch(event.getAction()){
            case MotionEvent.ACTION_DOWN:
                state=TouchState.DOWN;
                break;
            case MotionEvent.ACTION_UP:
                if(x==FormerX&&y==FormerY&&state==TouchState.DOWN){
                    try{
                        client.Send("Click");//点击
                    }
                    catch(Exception e){
                        msg.setText(e.toString());
                    }
                }
                state=TouchState.UP;
                break;
            case MotionEvent.ACTION_MOVE:
                try{
                    client.Send("D=("+(x-FormerX)+","+(y-FormerY)+")");
                }
                catch(Exception e){
                    msg.setText(e.toString());
                }
                state=TouchState.MOVING;
                canvas.drawLine(FormerX, FormerY, x, y, paint);//画线
                image.invalidate();
                break;
        }
        msg.setText("Touch:(" + x + "," + y + ")");
        //存储新值
        FormerX=x;
        FormerY=y;
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
