package com.example.ljbo.touchpad_3;
import java.net.*;
import java.io.*;
/**开线程创建连接
 * Created by LJbo on 2015/12/3.
 */
public class ConstructSocket extends Thread{
    private String IP;
    private int port;
    private Socket socket;
    //private boolean finished;
    ConstructSocket(String ip,int p){
        super();
        IP=ip;
        port=p;
        socket=null;
        //finished=false;
    }
    public void run(){
        BufferedReader is;
        for(int i=0;i<1;i++){//execute once
            try{
                socket=new Socket(IP,port);
                is=new BufferedReader(new InputStreamReader(socket.getInputStream()));//由Socket对象得到输入流，并构造相应的BufferedReader对象
                if(!(is.readLine()).equals("Ready"))
                    throw new NullPointerException();
            }
            catch(IOException ioe){
                socket=null;
                break;
            }
            catch(NullPointerException npe){
                socket=null;
                break;
            }
            //finished=true;
        }
        is=null;
    }
    public Socket getSocket(){
        //if(!finished)
        //    throw new IOException();
        return socket;
    }
    public String getIP(){
        return new String(IP);
    }
}

