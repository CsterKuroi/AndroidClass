package com.example.ljbo.touchpad_2;

/**触摸状态的数据结构
 * Created by LJbo on 2015/10/20.
 */
public enum TouchState {
    DOWN,MOVING,UP,CLICK_LEFT,CLICK_RIGHT
}
