package com.dycaly.TLMSever.Result;

public class FriendInfo {

	
	private String picurl;
	private String username;
	private String nickname;

	public FriendInfo(String picurl, String username, String nickname) {
		this.picurl = picurl;
		this.username = username;
		this.nickname = nickname;
	
	}
	
	
	
}
