package com.example.ljbo.touchpad_2;

import java.net.*;
import java.io.*;
/**开线程创建连接
 * Created by LJbo on 2015/10/17.
 */
public class ConstructSocket extends Thread{
    private String IP;
    private int port;
    private Socket socket;
    private boolean finished;
    ConstructSocket(String ip,int p){
        super();
        IP=ip;
        port=p;
        socket=null;
        finished=false;
    }
    public void run(){
        for(int i=0;i<1;i++){//execute once
            try{
                socket=new Socket(IP,port);
            }
            catch(IOException ioe){
                socket=null;
                break;
            }
        }
        finished=true;
    }
    public Socket getSocket()throws IOException{
        if(!finished)
            throw new IOException();
        return socket;
    }
    public String getIP(){
        return new String(IP);
    }
}
