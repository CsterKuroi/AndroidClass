package com.example.ljbo.touchpad_3;

import java.net.*;
import java.io.*;
import android.text.Editable;
import android.widget.EditText;
/**发送数据
 * Created by LJbo on 2015/12/3.
 */
public class Remote {
    private ConstructSocket constructor;
    private Socket socket;
    //private BufferedReader is;
    private PrintWriter os;
    private boolean OsUpdated;
    //private boolean IsUpdated;
    Remote() {
        socket = null;
        //is=null;
        os=null;
    }
    public void Send(String words) throws NullPointerException {
        for(int i=0;i<1;i++) {
            try {
                socket = constructor.getSocket();
                if(OsUpdated==false)
                    os = new PrintWriter(socket.getOutputStream());//由Socket对象得到输出流，并构造相应的BufferedReader对象
                OsUpdated=true;
            } catch (IOException ioe) {
                break;
            }
            synchronized (os) {
                os.println(words);//将从系统标准输入读入的字符串输出到Server
                os.flush();//刷新输出流，使Server马上收到该字符串
            }
        }
    }
    public void IPchange(String IP) throws NullPointerException {
        //Modifies:IP,socket
        //Effects:check IP has been changed or ,if changed, save the new one and construc a new socket
        constructor=new ConstructSocket(IP,4700);
        OsUpdated=false;
        constructor.start();
    }
    public boolean IsConnected(){
        return socket!=null;
    }
}
