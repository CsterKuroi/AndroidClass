package com.example.ljbo.touchpad_3;

/**工作模式的数据结构
 * Created by LJbo on 2015/12/5.
 */
public enum Pattern {
    GESTURE,MOVEMENT,SIMPLE
}
