package com.dycaly.TLMSever.Result;

public class HomeInfo {

	private int productid;
	private int which;
	public HomeInfo(int productid, int which) {
		this.productid = productid;
		this.which = which;
	}
	
}
