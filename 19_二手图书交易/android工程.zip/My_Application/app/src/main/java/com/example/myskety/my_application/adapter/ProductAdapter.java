package com.example.myskety.my_application.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myskety.my_application.R;
import com.example.myskety.my_application.data.ProductItem;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.ArrayList;

/**
 * Created by Myskety on 2015/11/8.
 */
public class ProductAdapter extends BaseAdapter{
    private Context context;
    private ArrayList<ProductItem> datas;

    public ProductAdapter(Context context){
        this.context = context;
        this.datas = new ArrayList<ProductItem>();
    }

    public int getCount(){
        return datas.size();
    }

    public ProductItem getItem(int position) {
        return datas.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public Context getContext() {
        return context;
    }

    public void clear(){
        datas.clear();
        notifyDataSetChanged();
    }

    public void addItem(ProductItem item){
        datas.add(item);
        notifyDataSetChanged();
    }
    public void addItem(int index,ProductItem item){
        datas.add(index,item);
        notifyDataSetChanged();
    }
    public void removeItem(int index){
        datas.remove(index);
        notifyDataSetChanged();
    }
    public View getView(int position,View convertView,ViewGroup parent){

        ViewHolder holder = null;
        if(convertView ==null){
            holder = new ViewHolder();
            convertView =LayoutInflater.from(getContext()).inflate(R.layout.product_list_cell,null);
            holder.imageView = (ImageView)convertView.findViewById(R.id.product_pic);
            holder.nameTV = (TextView)convertView.findViewById(R.id.product_name);
            holder.contentTV = (TextView)convertView.findViewById(R.id.product_content);
            holder.priceTV=(TextView)convertView.findViewById(R.id.product_price);
            convertView.setTag(holder);
        }
        else{
            holder = (ViewHolder) convertView.getTag();
        }
        ProductItem item = datas.get(position);
        ImageLoader.getInstance().displayImage(item.getProducturl(),holder.imageView);
        holder.nameTV.setText(item.getProductname());
        holder.contentTV.setText(item.getProductintro());
        holder.priceTV.setText("￥"+item.getLastprice()+".00");
        return convertView;

    }
    class ViewHolder{
        ImageView imageView;
        TextView nameTV;
        TextView contentTV;
        TextView priceTV;
    }
}
