package com.example.ljbo.touchpad_3;

import android.support.v4.view.MotionEventCompat;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View.OnClickListener;
import android.view.View;
import android.view.MotionEvent;
import android.view.KeyEvent;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;

public class MainActivity extends ActionBarActivity {
    SensorManager sensorManager;
    static final int sensor = SensorManager.SENSOR_ORIENTATION;
    private Sensor mySensor;
    private TextView msg;
    private Remote client;
    private Button ConnectBtn;
    private Button LeftBtn;
    private Button RightBtn;
    private EditText IPText;
    private TouchState state;
    private Pattern pattern;
    private String pstr;
    //below are angle
    private float x;
    private float y;
    private float z;
    //below is former position
    private Position pos;
    //private MySensorEventListener mySensorEventListener= new MySensorEventListener();//这个监听器当然是我们自己定义的，在方向感应器感应到手机方向有变化的时候，我们可以采取相应的操作，这里紧紧是将x,y,z的值打印出来
    private SensorEventListener mySensorEventListener = new SensorEventListener(){
        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) 		{			}
        @Override
        //可以得到传感器实时测量出来的变化值
        public void onSensorChanged(SensorEvent event) {
            //方向传感器
            if (event.sensor.getType() == Sensor.TYPE_ORIENTATION) {
                //x表示手机指向的方位，0表示北,90表示东，180表示南，270表示西
                x = event.values[SensorManager.DATA_X];
                y = event.values[SensorManager.DATA_Y];
                z = event.values[SensorManager.DATA_Z];
                //tv_orientation是界面上的一个TextView标签，不再赘述
                if(pattern==Pattern.GESTURE) {//体感打开
                    //msg.setText("Orientation:" + (int) x + "," + (int) y + "," + (int) z);
                    try {
                        client.Send("A=(" + x + "," + y + "," + z + ")");
                        msg.setText(pstr);
                    } catch (NullPointerException npe) {
                        msg.setText("尚未连接电脑！");
                    }
                }
            }
        }
    };
    private OnClickListener ConnectButtonListener = new OnClickListener() {
        public void onClick(View v) {
            //below are my code
            try{
                client.IPchange((IPText.getText()).toString());
            }
            catch(NullPointerException npe){
                //msg.setText("my"+(npe.getCause()).toString()+"\n");
                return;
            }
            catch(Exception e){
                //msg.setText(e.getCause() + "\n");
                return;
            }

        }
    };
    private OnClickListener LeftButtonListener = new OnClickListener() {
        public void onClick(View v) {
            //below are my code
            try{
                client.Send("Left");
                //state=TouchState.CLICK_LEFT;
                msg.setText(pstr+":左键");
            }
            catch(NullPointerException npe){
                //msg.setText("my"+(npe.getCause()).toString()+"\n");
                msg.setText("尚未连接电脑！");
                return;
            }
            catch(Exception e){
                //msg.setText(e.getCause() + "\n");
                return;
            }
        }
    };
    private OnClickListener RightButtonListener = new OnClickListener() {
        public void onClick(View v) {
            //below are my code
            try{
                client.Send("Right");
                //state=TouchState.CLICK_RIGHT;
                msg.setText(pstr+":右键");
            }
            catch(NullPointerException npe){
                //msg.setText("my"+(npe.toString()).toString());
                msg.setText("尚未连接电脑！");
                return;
            }
            catch(Exception e){
                //msg.setText(e.toString());
                return;
            }
        }
    };
    @Override
    protected void onResume() {
        Sensor sensor_orientation=sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);
        sensorManager.registerListener(mySensorEventListener, sensor_orientation, SensorManager.SENSOR_DELAY_UI);
        super.onResume();
    }
    @Override
    protected void onPause() {
    //注销所有传感器的监听
        sensorManager.unregisterListener(mySensorEventListener);
        super.onPause();
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float nowX=event.getX();
        float nowY=event.getY();
        String toSend=null;
        switch(event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                pos=new Position(nowX,nowY);//Update Position
                state=TouchState.DOWN;
                toSend=(pattern==Pattern.GESTURE)?"Down":null;
                break;
            case MotionEvent.ACTION_UP:
                if(pattern==Pattern.SIMPLE){
                    toSend=(pos.y<nowY)?"Former":(pos.y>nowY)?"Next":null;
                }
                else if(pattern==Pattern.GESTURE){
                    toSend="Up";
                }
                else{
                    toSend=(nowX==pos.x&&nowY==pos.y&&state==TouchState.DOWN)?"Click":null;
                    state=TouchState.UP;
                }
                pos=null;
                break;
            case MotionEvent.ACTION_MOVE:
                if(pattern==Pattern.MOVEMENT){
                    toSend="D=("+(nowX-pos.x)+","+(nowY-pos.y)+")";
                    pos=new Position(nowX,nowY);//Update Position
                }
                state=TouchState.MOVING;
                break;
        }
        if(toSend!=null){
            try {
                client.Send(toSend);
                msg.setText(pstr);
            }
            catch(NullPointerException npe){
                msg.setText("尚未连接电脑！");
            }
            catch (Exception e) {
                //msg.setText(e.toString());
            }
        }
        return super.onTouchEvent(event);
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            try {
                client.Send("Next");
                msg.setText(pstr+":下一页");
            } catch (NullPointerException npe) {
                msg.setText("尚未连接电脑！");
            }
            return true;
        }
        else if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            try {
                client.Send("Former");
                msg.setText(pstr+":上一页");
            } catch (NullPointerException npe) {
                msg.setText("尚未连接电脑");
            }
            return true;
        }
        else {
            return super.onKeyDown(keyCode, event);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // get sensor manager
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        // get compass sensor (ie magnetic field)
        mySensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        msg=(TextView) findViewById(R.id.MSGView);
        ConnectBtn = (Button) findViewById(R.id.ConnectButton);
        LeftBtn = (Button) findViewById(R.id.LeftButton);
        RightBtn=(Button)findViewById(R.id.RightButton);
        IPText=(EditText)findViewById(R.id.IPEdit);
        //设置按键监听
        ConnectBtn.setOnClickListener(ConnectButtonListener);
        LeftBtn.setOnClickListener(LeftButtonListener);
        RightBtn.setOnClickListener(RightButtonListener);
        //初始化属性
        client=new Remote();
        x=y=z=0;
        pos=new Position(0,0);
        pattern=Pattern.SIMPLE;
        pstr="遥控器模式";
        state=TouchState.UP;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatemens
        if (id == R.id.action_reset) {
            try{
                client.Send("R("+x+","+y+","+z+")");
                pstr="鼠标重定位";
                msg.setText(pstr);
            }catch(NullPointerException npe){
                msg.setText("尚未连接电脑！");
            }
            return true;
        }
        else if(id == R.id.action_simple){
            pattern=Pattern.SIMPLE;
            pstr="遥控器模式";
            msg.setText(pstr);
            return true;
        }
        else if(id == R.id.action_gesture){
            pattern=Pattern.GESTURE;
            pstr="手势模式";
            msg.setText(pstr);
            return true;
        }
        else if(id == R.id.action_movement){
            pstr="触摸板模式";
            msg.setText(pstr);
            pattern=Pattern.MOVEMENT;
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}