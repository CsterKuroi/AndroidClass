import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.AWTException;
class MouseController{
   private Robot robot;
   private int hh;//half of height
   private int hw;//half of width
   private int BX;//basic x
   private int BY;//basic y
   private int x; //now x
   private int y; //now y
   MouseController(){
      try{
         robot=new Robot();
      }
      catch(AWTException awte){
         awte.printStackTrace();
      }
      hw=700;
      hh=350;
      robot.mouseMove(hw,hh);
   }
   public void Control(String s)throws NullPointerException{
      switch(s.charAt(0)){
         case 'A'://���սǶ�
            String A[]=s.split("\\(|\\,|\\)");
            if(A.length==4){
               x=hw+(int)(  hw*Math.tan(Math.PI*(Math.round(Double.parseDouble(A[1]))-BX)/180));
               y=hh+(int)(2*hh*Math.tan(Math.PI*(Math.round(Double.parseDouble(A[2]))-BY)/180));
               //System.out.println("cursor:"+x+","+y);
	       robot.mouseMove(x,y);
            }
            break;
         case 'R':
            if(s.equals("Right")){//�Ҽ�����
               robot.mousePress(InputEvent.BUTTON3_MASK);
               robot.mouseRelease(InputEvent.BUTTON3_MASK); 
            }		
            else{
               String R[]=s.split("\\(|\\,|\\)"); 
               if(R.length==4){//���û�׼�Ƕ�
                  BX=(int)Math.round(Double.parseDouble(R[1]));
                  BY=(int)Math.round(Double.parseDouble(R[2]));
	          robot.mouseMove(hw,hh);
               }
            }
            break;
         case 'C':
         case 'L':
            if(s.equals("Left")||s.equals("Click")){//�������
               robot.mousePress(InputEvent.BUTTON1_MASK);
               robot.mouseRelease(InputEvent.BUTTON1_MASK); 
            }
            break;
         case 'D':
            if(s.equals("Down")){//�������
               robot.mousePress(InputEvent.BUTTON1_MASK);               
            }
            else{
               String D[]=s.split("\\(|\\,|\\)");
               if(D.length==3){
                  x+=(int)Double.parseDouble(D[1]);
                  y+=(int)Double.parseDouble(D[2]);
                  robot.mouseMove(x,y);
               }
            }
	    break;
         case 'U':
            if(s.equals("Up")){//����ɿ�
               robot.mouseRelease(InputEvent.BUTTON1_MASK); 
            }           
            break;
         case 'N':
            if(s.equals("Next")){//��һҳ
               //robot.mouseRelease(InputEvent.BUTTON1_MASK);
               robot.keyPress(KeyEvent.VK_DOWN);
               robot.keyRelease(KeyEvent.VK_DOWN);
            }
            break;
         case 'F':
            if(s.equals("Former")){//��һҳ
               //robot.mouseRelease(InputEvent.BUTTON1_MASK);
               robot.keyPress(KeyEvent.VK_UP);
               robot.keyRelease(KeyEvent.VK_UP);
            }
            break; 
     }    
   }
}